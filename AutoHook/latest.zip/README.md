```
https://raw.githubusercontent.com/InitialDet/DalamudPlugins/master/pluginmaster.json
```
